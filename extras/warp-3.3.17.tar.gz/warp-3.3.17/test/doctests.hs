import Test.DocTest

main :: IO ()
main = doctest ["Network"]
